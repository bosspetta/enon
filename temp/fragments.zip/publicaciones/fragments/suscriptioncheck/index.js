if(Liferay.ThemeDisplay.isSignedIn()){
		let suscriptedCategory = []
		let savedCategory = []
		if(step=="order-summary"){
				let table = document.querySelectorAll("table")[0];
				const cabecera = table.querySelector('thead tr');
				const th = document.createElement('th');
				th.textContent = 'Suscribirse';
				cabecera.prepend(th);

				try{
						let unsavedSuscriptions = await getUnsavedSuscription(userId, orderId)
						for(const unsavedSuscription of unsavedSuscriptions){
							await deleteSuscription(unsavedSuscription.id)
						}
				}catch(error){
						console.log("Ha ocurrido un error al actualizar las suscripciones")
				}

				const categories = skusArray.map(item => item.categoria)
				for(const category of Array.from(categories).values()){
						if(category && !suscriptedCategory.includes(category)){
								let items = await getSuscription(userId, category)
								if(items.length > 0){
										suscriptedCategory.push(category)
										savedCategory.push(items[0].saved)
								}
						}
				}

				const rows = table.querySelectorAll('tbody tr');
				for(const [index, row] of Array.from(rows).entries()) {
						const isRevista = skusArray[index]?.sku.startsWith("REVISTAS")
						const td = document.createElement('td');
						if(isRevista){
							const checkbox = document.createElement('input');
							checkbox.id = "check-"+index
							checkbox.type = 'checkbox';
							const categoryIndex = suscriptedCategory.indexOf(skusArray[index]?.categoria)
							checkbox.checked = categoryIndex != -1
							if(categoryIndex != -1){
									checkbox.disabled = savedCategory[categoryIndex]
							}
							td.appendChild(checkbox);
						}
						row.prepend(td);
					}

        const checkboxes = document.querySelectorAll('input[type="checkbox"][id^="check-"]');

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('click', async (e) => {
                e.preventDefault();
                const index = checkbox.id.split("-")[1];
                if(checkbox.checked){
                    try{
                        await postSuscription(userId, skusArray[index]?.categoria, orderId)
                        checkbox.checked = true
                        suscriptedCategory.push(skusArray[index]?.categoria)
                        savedCategory.push(false)
                        refreshCheckboxes(checkboxes, suscriptedCategory, savedCategory, skusArray, true)
                    }catch(error){
                        console.log("Ha ocurrido un error al suscribirse")
                    }
                }else{
                    try{
                        const categoryIndex = suscriptedCategory.indexOf(skusArray[index]?.categoria)
                        if(!savedCategory[categoryIndex]){
                            let item = await getSuscription(userId, skusArray[index]?.categoria)
                            await deleteSuscription(item[0].id)
                            checkbox.checked = false
                            suscriptedCategory = suscriptedCategory.filter(cat => cat !== skusArray[index]?.categoria)
                            refreshCheckboxes(checkboxes, suscriptedCategory, savedCategory, skusArray, false)
                        }
                    }catch(error){
                        console.log("Ha ocurrido un error al desuscribirse")
                    }
                }
            });
        });
		}else if(step=="order-confirmation"){
            try{
                let unsavedSuscriptions = await getUnsavedSuscription(userId, orderId)
                for(const unsavedSuscription of unsavedSuscriptions){
                    await saveSuscription(unsavedSuscription.id)
                }
            }catch(error){
                console.log("Ha ocurrido un error al persistir las suscripciones")
            }
		}
}

function refreshCheckboxes(checkboxes, suscriptedCategory, savedCategory, skusArray, marcar) {
		checkboxes.forEach(checkbox => {
				const index = checkbox.id.split("-")[1];
				if(marcar){
						if(suscriptedCategory.includes(skusArray[index]?.categoria)){
								checkbox.checked = true
						}
				}else {
						if(!suscriptedCategory.includes(skusArray[index]?.categoria)){
								checkbox.checked = false
						}
				}
		});
}

async function saveSuscription(suscriptionId) {
    const authToken = Liferay.authToken;
    const config = {
        method: "PATCH",
        timeout: 5000,
        dataType: "json",
        body: JSON.stringify({
            "saved": true
        }),
        headers: {
          'Content-Type': 'application/json',
          'accept': 'application/json',
          'x-csrf-token': authToken
        }
    }
    return await fetch(`/o/c/suscripcions/${suscriptionId}`, config);
}

async function getSuscription(userId,categoryId) {
    const authToken = Liferay.authToken;
    const response = await fetch(`/o/c/suscripcions/?filter=categoriaSuscritaId%20eq%20${categoryId}%20and%20usuarioSuscritoId%20eq%20${userId}&p_auth=${authToken}`);
    const data = await response.json();
    return data.items;
}

async function getUnsavedSuscription(userId, orderId) {
    const authToken = Liferay.authToken;
    const response = await fetch(`/o/c/suscripcions/?filter=saved%20eq%20false%20and%20usuarioSuscritoId%20eq%20${userId}%20and%20subscripcionOrderId%20eq%20${orderId}&p_auth=${authToken}`);
    const data = await response.json();
    return data.items;
}

async function postSuscription(userId,categoryId, orderId) {
    const authToken = Liferay.authToken;
    const config = {
        method: "POST",
        timeout: 5000,
        dataType: "json",
        body: JSON.stringify({
            "categoriaSuscritaId": categoryId,
            "usuarioSuscritoId": userId,
            "saved": false,
						"subscripcionOrderId": orderId,
        }),
        headers: {
          'Content-Type': 'application/json',
          'accept': 'application/json',
          'x-csrf-token': authToken
        }
    }
    return await fetch(`/o/c/suscripcions/`, config);
}

async function deleteSuscription(suscriptionId) {
    const authToken = Liferay.authToken;
    return await fetch(`/o/c/suscripcions/${suscriptionId}?p_auth=${authToken}`,{'method':'DELETE'});
}
