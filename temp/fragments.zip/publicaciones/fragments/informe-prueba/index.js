async function fetchWarehouseId() {
	let authToken = Liferay.authToken;
	const response = await fetch(
		`/o/headless-commerce-admin-inventory/v1.0/warehouses?p_auth=${authToken}`
	);
	const data = await response.json();
	return data.items[0].id;
}

async function fetchWarehouseItems(warehouseId) {
	let authToken = Liferay.authToken;
	const response = await fetch(
		`/o/headless-commerce-admin-inventory/v1.0/warehouses/${warehouseId}/warehouseItems?pageSize=-1&p_auth=${authToken}`
	);
	const data = await response.json();
	return data || [];
}

async function getProductBySku(sku, authToken){
	const response = await fetch(
        `/o/headless-commerce-admin-catalog/v1.0/products?pageSize=-1&search="${sku}"&p_auth=${authToken}`
    );
    const data = await response.json();
    return [data.items[0] ? data.items[0]?.name.es_ES : "", data.items[0] ? data.items[0]?.catalogId : "", data.items[0] ? data.items[0]?.productId : ""];
}

async function getCatalogNameById(catalogId, authToken){
	const response = await fetch(
        `/o/headless-commerce-admin-catalog/v1.0/catalog/${catalogId}?p_auth=${authToken}`
    );
    const data = await response.json();
    return data.name
}

async function getAgcSpecification(productId, authToken){
	const response = await fetch(
		`/o/headless-commerce-admin-catalog/v1.0/products/${productId}/productSpecifications?p_auth=${authToken}`
	);
	const data = await response.json();
	return data.items.find(field => field.specificationKey === 'agc-key') ? data.items.find(field => field.specificationKey === 'agc-key')?.value.es_ES : "";
}

async function getSkuQuantity(listaProductos){
	let authToken = Liferay.authToken;
	//console.log(JSON.stringify(listaProductos.items.length))
	var lista = {
    items : [],
		lastPage: listaProductos.lastPage,
		page : listaProductos.page,
		pageSize : listaProductos.pageSize,
		totalCount : listaProductos.totalCount
	};
	//console.log(JSON.stringify(listaProductos.items))
//alert(lista.totalCount)
	for(var i=0; i< listaProductos.items.length; i++){
		var [productName, catalogId, productId] = await getProductBySku(listaProductos.items[i].sku, authToken)
		var catalogName = "";
		var agc=""
		if(catalogId != "" && productId != ""){
			catalogName = await getCatalogNameById(catalogId, authToken)
			agc = await getAgcSpecification(productId, authToken)
		}
		lista.items.push({"agc": agc, "productName":productName, "catalogName":catalogName, "sku":listaProductos.items[i].sku, "quantity":listaProductos.items[i].quantity});
	}
	//alert(lista.items[0])
	console.log(JSON.stringify(lista))
	return lista
}

var response = getSkuQuantity(await fetchWarehouseItems(await fetchWarehouseId()))