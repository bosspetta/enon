const spam = ["money","cash","bonus","win","free","offer","loan","income","profit","investment","trading","bitcoin","btc","crypto","forex","casino","sex","porn","xxx","nude","girls","escort","dating","hot","love","viagra","telegram","whatsapp","onlyfans"];
const url = ["http://","https://","www.",".com",".ru",".cn",".xyz",".top",".info",".org",".biz",".click",".site",".online",".pw","bit.ly","tinyurl","cutt.","shorturl"];
const xss = ["<",">","script","onerror","onload","alert","eval","javascript:","iframe","svg","img","src=","href=","data:"];
const symbols = ["{","}","[","]","(",")","=","+","*","&","^","%","$","#","@","!","?",";",":","\"","'","`","´","«","»","|","~","/","\\"];
const fake = ["aaa","zzz","111","123456","qwerty","asdf","test","demo","sample","user","bot","null","undefined"];
const sql = ["'","\""," or "," and ","1=1","drop","select","insert","update","delete","--","/*","*/"];
const emoji = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u;

function validate(value) {
  if (!value) return false;
  const v = value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase();
  if (!v) return false;
  if (/\d/.test(v)) return false;
  if (/[A-Z]{2,}/.test(value)) return false;
  if (v.length < 2 || v.length > 80) return false;
  if (emoji.test(v)) return false;
  const all = [spam, url, xss, symbols, fake, sql];
  for (const arr of all) for (const w of arr) if (v.includes(w)) return false;
  return true;
}

const nombre = document.querySelector('#_pub_crear_cuenta_PubCrearCuentaPortlet_pub-nombre');
const p1 = document.querySelector('#_pub_crear_cuenta_PubCrearCuentaPortlet_pub-primerApellido');
const p2 = document.querySelector('#_pub_crear_cuenta_PubCrearCuentaPortlet_pub-segundoApellido');
const btn = document.querySelector('form[id*="_PubCrearCuentaPortlet"] button[type="submit"], form[id*="_PubCrearCuentaPortlet"] input[type="submit"]');

if (nombre && p1 && p2 && btn) {
  function revisar() {
    nombre.value = nombre.value.replace(/\s+/g, ' ').trim();
    p1.value = p1.value.replace(/\s+/g, ' ').trim();
    p2.value = p2.value.replace(/\s+/g, ' ').trim();
    const valid = validate(nombre.value) && validate(p1.value) && validate(p2.value);
    btn.disabled = !valid;
  }

  ['input', 'change', 'keyup'].forEach(evt => {
    nombre.addEventListener(evt, revisar);
    p1.addEventListener(evt, revisar);
    p2.addEventListener(evt, revisar);
  });

  revisar();
}

document.addEventListener('DOMContentLoaded', function () {
  const inputElement = document.querySelector('#_pub_crear_cuenta_PubCrearCuentaPortlet_pub-dni');
  const parentFormGroup = inputElement?.closest('.form-group.pub-registration__form-group.input-text-wrapper');
  if (parentFormGroup) {
    parentFormGroup.style.display = 'none';
  }
});
