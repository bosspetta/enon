
let url = new URLSearchParams(window.location.search);

//Declaracion de las distintas zonas y los paises a los que pertenecen


let nacional = ["ES"];

//Zonas Premium

let premiumZonaEU1 = ["DE", "AT", "GG", "BE", "DK", "FR", "GI", "GR", "IE", "IT",
  "JE", "LU", "MC", "NO", "NL", "PT", "GB", "SM", "SE", "CH", "VA"];
let premiumZonaEU2 = ["DZ", "BG", "CY", "HR", "SK", "SI", "EE", "FI", "GL", "HU",
  "IS", "FO", "XK", "LV", "LI", "LT", "MA", "ME", "PL", "CZ",
  "RO", "RU", "RS", "TN", "TR", "UA"];
let premiumZonaAM = ["AG", "AG", "AR", "AW", "BS", "BB", "BZ", "BM", "BO", "BR",
  "CA", "CL", "CO", "CR", "CU", "CW", "DM", "EC", "SV", "US",
  "GD", "GT", "GY", "HT", "HN", "KY", "JM", "MX", "NI", "PA",
  "PY", "PE", "DO", "KN", "KN", "VC", "VC", "LC", "SR", "TT",
  "TT", "UY", "VE"];
let premiumZonaASOC = ["AF", "SA", "AM", "AU", "AZ", "BH", "BD", "BN", "BT", "KH",
  "CN", "KP", "KR", "AE", "PH", "GE", "HK", "IN", "ID", "IR",
  "IQ", "FJ", "MH", "SB", "IL", "JP", "JO", "KZ", "KG", "KI",
  "KW", "LA", "LB", "MO", "MY", "MV", "MN", "MM", "NR", "NP",
  "NC", "NZ", "OM", "PK", "PW", "PG", "QA", "WS", "SG", "SY",
  "LK", "TH", "TW", "TJ", "PS", "TL", "TO", "TM", "TV", "UZ",
  "VU", "VN", "YE"];
let premiumZonaAF = ["AO", "BJ", "BW", "BF", "BI", "CV", "CM", "TD", "KM", "CI",
  "DJ", "EG", "ER", "ET", "GA", "GM", "GH", "GN", "GW", "GQ",
  "KE", "LS", "LR", "LY", "MG", "MW", "ML", "MR", "MZ", "NA",
  "NE", "NG", "CF", "CG", "CD", "RW", "SN", "SC", "SL", "SO",
  "ZA", "SD", "SS", "SZ", "TZ", "TG", "UG", "ZM", "ZW"];


//Zonas Standard

let standardZonaEU1 = ["DE", "AT", "GG", "BE", "DK", "FR", "GI", "GR", "IE", "IT", "JE", "LU", "MC", "NO", "NL", "PT", "GB", "SM", "SE", "CH", "VA"];
let standardZonaEU2 = ["DZ", "BG", "CY", "HR", "SK", "SI", "EE", "FI", "GL", "HU", "IS", "FO", "XK", "LV", "LI", "LT", "MA", "ME", "PL", "CZ", "RO", "TN"];
let standardZonaEU3 = ["AL", "BY", "BA", "MK", "MT", "MD", "RU", "RS", "TR", "UA"];
let standardZonaAM = ["AG", "AG", "AR", "AW", "BS", "BB", "BZ", "BM", "BO", "BR", "CA", "CL", "CO", "CR", "CU", "CW", "DM", "EC", "SV", "US", "GD", "GT", "GY", "HT", "HN", "KY", "JM", "MX", "NI", "PA", "PY", "PE", "DO", "KN", "KN", "VC", "VC", "LC", "SR", "TT", "TT", "UY", "VE"];
let standardZonaASOC = ["AF", "SA", "AM", "AZ", "BH", "BD", "BN", "BT", "KH", "CN", "KP", "KR", "AE", "PH", "GE", "HK", "IN", "ID", "IR", "IQ", "FJ", "MH", "SB", "IL", "JP", "JO", "KZ", "KG", "KI", "KW", "LA", "LB", "MO", "MY", "MV", "MN", "MM", "NR", "NP", "NC", "OM", "PK", "PW", "PG", "QA", "WS", "SG", "SY", "LK", "TH", "TW", "TJ", "PS", "TL", "TO", "TM", "TV", "VU", "VN", "YE"];
let standardZonaASOC2 = ["AU", "NZ", "UZ"];
let standardZonaAF = ["AO", "BJ", "BW", "BF", "BI", "CV", "CM", "TD", "KM", "CI", "DJ", "EG", "ER", "ET", "GA", "GM", "GH", "GN", "GW", "GQ", "KE", "LS", "LR", "LY", "MG", "MW", "ML", "MR", "MZ", "NA", "NE", "NG", "CF", "CG", "CD", "RW", "SN", "SC", "SL", "SO", "ZA", "SD", "SS", "SZ", "TZ", "TG", "UG", "ZM", "ZW"];




if(url.get("_com_liferay_commerce_checkout_web_internal_portlet_CommerceCheckoutPortlet_checkoutStepName") == "shipping-method"){
	$(".loader").show();
	$(".loader").prependTo($("form#_com_liferay_commerce_checkout_web_internal_portlet_CommerceCheckoutPortlet_fm"));

	
	//Dado un pedido, obtenemos los productos de ese pedido y sus pesos. Además obtenemos la provincia a donde se va a realizar el envio.
	//Con toda esta información el sistema selecciona el método de envio adecuado.
	let order = await getCurrentOrderID(url);	
	let orderItems = await getCurrentOrderProducts(order.id);
	let pais = await getPaisSeleccionado(order.id);
	
	let sumaPesos = 0.0;
	let items = orderItems.items;
	
	for(let i in items){		
		let skuId = items[i].skuId;
		let quantity = items[i].quantity;
		let productId = await getProductIdBySku(skuId);
		let peso = await getPesoProducto(productId);
		if((typeof peso == 'undefined')|| (peso==0)){
			peso = 0.3;
		}		
		sumaPesos += peso * quantity;
	}
	let zonasSeleccionadas = await obtieneZonas(pais);
	let tipoPeso = await calculaTipoPeso(sumaPesos);
	muestraEnvioSeleccionado(zonasSeleccionadas, tipoPeso);


}


async function obtieneZonas(pais) {
  const todasLasZonas = {nacional, premiumZonaEU1, premiumZonaEU2, premiumZonaAM,
    premiumZonaASOC, premiumZonaAF, standardZonaEU1, standardZonaEU2,
    standardZonaEU3, standardZonaAM, standardZonaASOC, standardZonaASOC2,
    standardZonaAF};

  const zonas = Object.entries(todasLasZonas)
    .filter(([nombre, zona]) => zona.includes(pais))
    .map(([nombre]) => nombre);

  return zonas;
}


 
async function getCurrentOrderID(url) {
	const externalReferenceCode = url.get("_com_liferay_commerce_checkout_web_internal_portlet_CommerceCheckoutPortlet_commerceOrderUuid");
	const authToken = Liferay.authToken;
	//Obtiene el pedido actual mediante el identificador de la URL
	const response = await fetch(`/o/headless-commerce-admin-order/v1.0/orders/by-externalReferenceCode/${externalReferenceCode}?p_auth=${authToken}`);
	const data = await response.json();
	return data;
}


async function getProductIdBySku(sku) {	
	const authToken = Liferay.authToken;
	//Obtiene el id de pedido actual mediante el sku
	const response = await fetch(`/o/headless-commerce-admin-catalog/v1.0/skus/${sku}?p_auth=${authToken}`);
	const data = await response.json();
	return data.productId;
}
 
 
async function getCurrentOrderProducts(orderId) {	
	const authToken = Liferay.authToken;
	//Obtiene todos los productos del pedido actual
	const response = await fetch(`/o/headless-commerce-admin-order/v1.0/orders/${orderId}/orderItems?p_auth=${authToken}`);
	const data = await response.json();
	return data;
}
 
async function getPesoProducto(productId) {	
	const authToken = Liferay.authToken;
	//Obtiene el peso de un producto
	const response = await fetch(`/o/headless-commerce-admin-catalog/v1.0/products/${productId}/shippingConfiguration?p_auth=${authToken}`);
	const data = await response.json();
	return data.weight;
}
 
async function getPaisSeleccionado(orderId) {
	const authToken = Liferay.authToken;
	//Obtiene pais	seleccionado
	const response = await fetch(`/o/headless-commerce-admin-order/v1.0/orders/${orderId}/shippingAddress?p_auth=${authToken}`);
	const data = await response.json();
	return data.countryISOCode;
} 
 


function muestraEnvioSeleccionado(tipoEnvio, tipoPeso) {	
	
	tipoEnvio = tipoEnvio[0].toString().replaceAll(' ', '').toUpperCase();
	tipoPeso = tipoPeso.replaceAll(' ', '').toUpperCase();
	for (let i = 0; i < $("li.commerce-shipping-types.list-group-item.list-group-item-flex label").length; i++) {
	  let opcionEnvio = $("li.commerce-shipping-types.list-group-item.list-group-item-flex label")[i].innerText;
	  opcionEnvio = opcionEnvio.replaceAll(" ", "").toUpperCase();
	  if((opcionEnvio.includes(tipoEnvio)) && (opcionEnvio.includes(tipoPeso))){
		$("li.commerce-shipping-types.list-group-item.list-group-item-flex").eq(i).show();
		$("li.commerce-shipping-types.list-group-item.list-group-item-flex input").eq(i).attr("Checked",true);
		$(".loader").hide();
	  }
	}
	$(".loader").hide();
		$("li.commerce-shipping-types.list-group-item.list-group-item-flex").last().show();
	$("li.commerce-shipping-types.list-group-item.list-group-item-flex input").last().attr("Checked",true);
}


async function calculaTipoPeso(sumaPesos) {
 
	let tipoEnvio="";
	switch (true) {
		case (sumaPesos < 0.250):
			tipoEnvio = "Hasta 250g";
			break;
		case (sumaPesos < 0.500):
			tipoEnvio = "Más de 250g hasta 500g";
			break;
		case (sumaPesos < 1.0):
			tipoEnvio = "Más de 500g hasta 1Kg";
			break;
		case (sumaPesos < 1.5):
			tipoEnvio = "Más de 1Kg hasta 1,5Kg";
			break;
		case (sumaPesos < 2.0):
			tipoEnvio = "Más de 1,5Kg hasta 2Kg";
			break;
		default:
			tipoEnvio = "Más de 2Kg hasta 30Kg: tarifa hasta 2Kg + tarifa por cada kilogramo o fracción de kilogramo";
			break;
	}
	return tipoEnvio;
}

