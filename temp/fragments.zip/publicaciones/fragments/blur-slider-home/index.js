
window.addEventListener('load', function () {
  const destacados = document.querySelector('.lfr-layout-structure-item-container.destacados .lfr-layout-structure-item-collection .row.align-items-start');
  if (destacados) {
    destacados.style.display = 'grid';
  }
});
