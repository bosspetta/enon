const btnMenu = document.querySelector('.main-header__btn-menu')
const mainMenu = document.querySelector('.main-nav')

const closeMenu = document.querySelector('.main-nav__btn-menu')

btnMenu.addEventListener('click', () => {
    document.body.classList.add('open-menu')
    mainMenu.classList.add('show')
})

closeMenu.addEventListener('click', () => {
    document.body.classList.remove('open-menu')
    mainMenu.classList.remove('show')
})

function wrapFirstTwoAndRestInSpans() {
    const originalSpan = document.querySelector('.main-header__site-name__link__label')
    if (!originalSpan) return

    const words = originalSpan.textContent.trim().split(/\s+/)
    const firstTwo = words.slice(0, 2).join(' ')
    const rest = words.slice(2).join(' ')

    originalSpan.innerHTML = `<span class="main-header__site-name__link__label__section main-header__site-name__link__label__section--01">${firstTwo}</span><span class="main-header__site-name__link__label__section main-header__site-name__link__label__section--02">${rest}</span>`
}

wrapFirstTwoAndRestInSpans()