const currentURL = window.location.href

const linkedinShare = 'https://www.linkedin.com/sharing/share-offsite/?url='
const whatsappShare = 'https://wa.me/?text=Mira%20este%20art%C3%ADculo%20interesante%3A%20'
const xShare = 'https://twitter.com/intent/tweet?text=Mira%20este%20art%C3%ADculo%20interesante%3A%20'
const facebookShare = 'https://www.facebook.com/sharer/sharer.php?u='

const linkedinURL = `${linkedinShare}${currentURL}`
const whatsappURL = `${whatsappShare}${currentURL}`
const xURL = `${xShare}${currentURL}`
const facebookURL = `${facebookShare}${currentURL}`

const linkedinLink = document.getElementById('linkedin-link')
const whatsappLink = document.getElementById('whatsapp-link')
const xLink = document.getElementById('x-link')
const facebookLink = document.getElementById('facebook-link')

linkedinLink.setAttribute('href', `${linkedinURL}`)
whatsappLink.setAttribute('href', `${whatsappURL}`)
xLink.setAttribute('href', `${xURL}`)
facebookLink.setAttribute('href', `${facebookURL}`)
